<?php
$conn = mysqli_connect('localhost', 'root', '', 'coursework1');
